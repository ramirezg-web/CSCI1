# Ramirez Gentle Assignement 10 Part 0


thesaurus = {
               "happy": "glad",
               "sad"  : "bleak"
             }
phrase = input("Enter a phrase: ")
punctuations = "'!\"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'"
newphrase = "" #without punctuation
#loop through 
for x in phrase.lower():
    if x not in punctuations:
        newphrase += x
final = ""
for x in newphrase.split(" "): 
    if x in thesaurus.keys():
        final += thesaurus[x].upper()
    else:
        final += x
    final += " "
final = final[:-1]


print(final)
