# define our simple thesaurus
thesaurus = {
               "happy": "glad",
               "sad"  : "bleak"
             }
word = input("Enter a phrase: ")
punctuations = "'!\"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'"
text = ""
for x in word.lower():
    if x not in punctuations:
        text += x
result = ""
for x in text.split(" "):
    if x in thesaurus.keys():
        result += thesaurus[x].upper()
    else:
        result += x
    result += " "
result = result[:-1]
print(result)
