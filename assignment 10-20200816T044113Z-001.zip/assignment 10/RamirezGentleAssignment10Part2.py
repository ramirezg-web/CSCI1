#Ramirez Gentle Assignment 10 #part 2

import random
import string

def dictionary(filename):
    infile = open(filename, 'r')
    thesaurus = {}
    for line in infile.readlines():
        line = line.strip()
        line = line.split(',')
        thesaurus[line[0]] = line[1:]
    infile.close()

    return thesaurus

def final(thesaurus, phrase):
#part 1/ actual thesaurus work
    new_phrase = ""
    phrase = phrase.split()
    for i in range(len(phrase)):
        phrase[i] = phrase[i].strip(string.punctuation)
        phrase[i] = phrase[i].lower()
    for word in phrase:
        if word in thesaurus.keys():
            replace = thesaurus[word][random.randrange(len(thesaurus[word]))]
            replace = replace.upper()
            new_phrase = new_phrase + replace + " "
        else:
            new_phrase = new_phrase + word + " "
    return new_phrase

def main():
    #assign9 get file
    filename = "python_asg10_Roget_Thesaurus.txt"
    thesaurus = dictionary(filename) #read and split 
    print("Total words in the thesaurus: " + str(len(thesaurus)))
    phrase = input("Enter a phrase: ") 
    new_phrase = final(thesaurus, phrase)
    print(new_phrase)

# Call the main()

if __name__ == "__main__":

    main()
