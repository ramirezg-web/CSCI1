#part 2
# Import the required packages.

import random

import string


# Define the function to create the dictionary.

def create_dictionary(filename):

    # Open the file in read mode.

    infile = open(filename, 'r')

    # Declare a dictionary.

    thesaurus = {}

    # Start the loop to read the file.

    for line in infile.readlines():

        # Remove the whitespaces from the line.

        line = line.strip()

        # Split the line by ','.

        line = line.split(',')

        # Store the first word as the key

        # and rest of the words as the values

        # in the dictionary.

        thesaurus[line[0]] = line[1:]

    # Close the file and return the dictionary.

    infile.close()

    return thesaurus

# Define the function to replace the words.

def replace_words(thesaurus, phrase):

    # Create a string to store the result.

    new_phrase = ""

    # Split the words.

    phrase = phrase.split()

    # Start the loop to traverse the words.

    for i in range(len(phrase)):

        # Remove the punctuations from each word.

        phrase[i] = phrase[i].strip(string.punctuation)

        # Convert each word in lower case.

        phrase[i] = phrase[i].lower()

    # Start the loop to traverse the words.

    for word in phrase:

        # Search the word in the dictionary.

        if word in thesaurus.keys():

            # Find and store a random replacement of the word.

            replace = thesaurus[word][random.randrange(len(thesaurus[word]))]

            # Convert the replacement in uppercase.

            replace = replace.upper()

            # Add the replacement in the new phrase.

            new_phrase = new_phrase + replace + " "

        # Add the word in the new phrase if it

        # is not found in the dictionary.

        else:

            new_phrase = new_phrase + word + " "

    # Return the new phrase.

    return new_phrase

# Define the main() function.

def main():

    # Store the name of the file.

    filename = "python_asg10_Roget_Thesaurus.txt"

    # Call the function and store the result.

    thesaurus = create_dictionary(filename)

    # Display the total number of words in the dictionary.

    print("Total words in the thesaurus: " + str(len(thesaurus)))

    # Prompt the user to enter the phrase.

    phrase = input("Enter a phrase: ")

    # Call the function and store the modified phrase.

    new_phrase = replace_words(thesaurus, phrase)

    # Print the modified phrase.

    print(new_phrase)

# Call the main() function.

if __name__ == "__main__":

    main()
