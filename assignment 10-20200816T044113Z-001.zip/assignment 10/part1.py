#Ramirez Gentle Assignment 10 Part 1

from random import choice
thesaurus = {
               "happy":["glad", "blissful", "ecstatic", "at ease"],
               "sad" :["bleak", "blue", "depressed"]

             }


happy="happy"
sad="sad"
i=0
phrase = input("Enter your input: ")
n=len(phrase)
newphrase=""


while i < n:
    if phrase[i]!=" " and phrase[i]!=',' :
       newphrase=newphrase +phrase[i].lower()
    elif newphrase == happy :
      newphrase=choice(thesaurus["happy"])
      print (newphrase.upper(), end=" ",)
      newphrase=""
    elif newphrase == sad:
      newphrase=choice(thesaurus["sad"])
      print (newphrase.upper(),end=" ")
      newphrase=""
    else:
      print (newphrase,end=" ")
      newphrase=""
    i=i+1

print (newphrase)
